const form = document.getElementById('contactForm');
const status = document.getElementById('status');
const yearSpan = document.getElementById('year');
yearSpan.textContent = new Date().getFullYear();

form.addEventListener('submit', async (e) =>{
  e.preventDefault();
  status.textContent = 'Sending...';
  const payload = {
    name: document.getElementById('name').value,
    email: document.getElementById('email').value,
    message: document.getElementById('message').value
  };

  try{
    const res = await fetch('http://localhost:8080/api/contact', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify(payload)
    });

    if(res.ok){
      status.textContent = 'Message sent — thanks!';
      form.reset();
    } else {
      const text = await res.text();
      status.textContent = 'Server error: ' + (text || res.status);
    }
  } catch(err){
    status.textContent = 'Network error — is the backend running?';
    console.error(err);
  }
});
