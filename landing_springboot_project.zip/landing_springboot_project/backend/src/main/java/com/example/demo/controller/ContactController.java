package com.example.demo.controller;

import com.example.demo.model.Contact;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api")
public class ContactController {

    @CrossOrigin(origins = "*")
    @PostMapping("/contact")
    public ResponseEntity<String> receiveContact(@RequestBody Contact contact){
        System.out.println("New contact submitted: " + contact);
        return ResponseEntity.ok("Received");
    }
}
